package com.holoowah.proxyreload

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class ProxyControlService : Service() {
    companion object {
        const val ACTION_START = "com.holoowah.proxyreload.START"
        const val ACTION_RELOAD = "com.holoowah.proxyreload.RELOAD"
        const val ACTION_STOP = "com.holoowah.proxyreload.STOP"
        const val ACTION_DISMISS = "com.holoowah.proxyreload.DISMISS"
        const val CHANNEL = "proxy_control"
        const val NOTIFICATION_ID = 7102
    }

    private var state = "READY"

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                state = "STOPPED"
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> {
                // Hook for the real proxy engine: stop it and reconnect.
                state = "RELOAD REQUESTED"
                showNotification("Reload requested")
                return START_STICKY
            }
            ACTION_START, null -> state = "READY"
        }
        startForeground(NOTIFICATION_ID, buildNotification("Controls ready"))
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Proxy controls", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Persistent notification with reload and stop controls"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun action(label: String, action: String): NotificationCompat.Action {
        val intent = Intent(this, ProxyControlService::class.java).setAction(action)
        val pending = PendingIntent.getService(this, action.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Action.Builder(0, label, pending).build()
    }

    private fun buildNotification(message: String) =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentTitle("Proxy Reload")
            .setContentText(message)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(action("RELOAD", ACTION_RELOAD))
            .addAction(action("STOP", ACTION_STOP))
            .build()

    private fun showNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(message))
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
