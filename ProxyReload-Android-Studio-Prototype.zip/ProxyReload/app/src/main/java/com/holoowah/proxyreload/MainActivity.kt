package com.holoowah.proxyreload

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var host: EditText
    private lateinit var port: EditText
    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var type: Spinner
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.TOP
        }
        layout.addView(TextView(this).apply {
            text = "Proxy Reload"
            textSize = 26f
        })
        layout.addView(TextView(this).apply {
            text = "Save your proxy details and use the notification buttons to control the service."
            textSize = 14f
        })
        type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("SOCKS5", "HTTP"))
        layout.addView(label("Proxy type"))
        layout.addView(type)
        host = field("Proxy IP / hostname", layout)
        port = field("Port", layout)
        username = field("Username (optional)", layout)
        password = field("Password (optional)", layout).apply {
            inputType = 129
        }

        val save = Button(this).apply {
            text = "Save proxy details"
            setOnClickListener {
                val p = port.text.toString().toIntOrNull()
                if (host.text.toString().trim().isEmpty() || p == null || p !in 1..65535) {
                    status.text = "Enter a proxy host and a valid port (1–65535)."
                } else {
                    getSharedPreferences("proxy", MODE_PRIVATE).edit()
                        .putString("type", type.selectedItem.toString())
                        .putString("host", host.text.toString().trim())
                        .putInt("port", p)
                        .putString("username", username.text.toString())
                        .putString("password", password.text.toString())
                        .apply()
                    status.text = "Proxy details saved on this device."
                }
            }
        }
        layout.addView(save)
        val start = Button(this).apply {
            text = "Show notification controls"
            setOnClickListener {
                val saved = getSharedPreferences("proxy", MODE_PRIVATE)
                if (saved.getString("host", null).isNullOrBlank()) {
                    status.text = "Save your proxy details first."
                } else {
                    val i = Intent(this@MainActivity, ProxyControlService::class.java)
                        .setAction(ProxyControlService.ACTION_START)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    status.text = "Control notification started. See prototype limitation below."
                }
            }
        }
        layout.addView(start)
        status = TextView(this).apply {
            text = "Status: idle"
            textSize = 14f
            setPadding(0, pad, 0, pad)
        }
        layout.addView(status)
        layout.addView(TextView(this).apply {
            text = "Prototype limitation: this project implements the notification controls and stores proxy settings, but it does not yet route phone traffic through the proxy. A VPN/tun2socks engine must be integrated and tested before it can function as a real proxy client."
            textSize = 13f
        })
        setContentView(ScrollView(this).apply { addView(layout) })
        loadSaved()
    }

    private fun label(s: String) = TextView(this).apply { text = s; textSize = 14f }
    private fun field(hintText: String, layout: LinearLayout): EditText {
        layout.addView(label(hintText))
        return EditText(this).apply {
            hint = hintText
            singleLine = true
            layout.addView(this)
        }
    }
    private fun loadSaved() {
        val prefs = getSharedPreferences("proxy", MODE_PRIVATE)
        host.setText(prefs.getString("host", ""))
        val p = prefs.getInt("port", 0)
        if (p != 0) port.setText(p.toString())
        username.setText(prefs.getString("username", ""))
        password.setText(prefs.getString("password", ""))
        type.setSelection(if (prefs.getString("type", "SOCKS5") == "HTTP") 1 else 0)
    }
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }
}
